"""Exercise the unmodified pinned Cherchi executable on analytical boxes.

Only artifacts in this dedicated native-build directory are written.  Exact
integration below certifies the saved binary64 boundary moments of these small
examples. It is not a certificate of arbitrary Cherchi implicit geometry.
"""

from collections import Counter
from fractions import Fraction as Q
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parent
BINARY = ROOT / "build/bin/w4_cherchi_reference_native"
WORK = ROOT / "analytical-smoke"
WORK.mkdir(exist_ok=True)
MOMENT_NAMES = ("1", "x", "y", "z", "x2", "y2", "z2", "xy", "yz", "xz")
EXPONENTS = ((0, 0, 0), (1, 0, 0), (0, 1, 0), (0, 0, 1),
             (2, 0, 0), (0, 2, 0), (0, 0, 2), (1, 1, 0),
             (0, 1, 1), (1, 0, 1))
FACES = ((0, 2, 1), (0, 3, 2), (4, 5, 6), (4, 6, 7),
         (0, 1, 5), (0, 5, 4), (3, 7, 6), (3, 6, 2),
         (0, 4, 7), (0, 7, 3), (1, 2, 6), (1, 6, 5))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_cube(path, lo, hi):
    vertices = ((lo, lo, lo), (hi, lo, lo), (hi, hi, lo), (lo, hi, lo),
                (lo, lo, hi), (hi, lo, hi), (hi, hi, hi), (lo, hi, hi))
    path.write_text("".join("v %s %s %s\n" % p for p in vertices)
                    + "".join("f %d %d %d\n" % tuple(i + 1 for i in f)
                              for f in FACES))


def cross(a, b):
    return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])


def read_mesh(path):
    vertices, faces = [], []
    for line in path.read_text().splitlines():
        fields = line.split()
        if not fields:
            continue
        if fields[0] == "v":
            assert len(fields) == 4
            vertices.append(tuple(Q.from_float(float(x)) for x in fields[1:]))
        elif fields[0] == "f":
            assert len(fields) == 4
            faces.append(tuple(int(x.split("/")[0])-1 for x in fields[1:]))
    assert vertices and faces
    return vertices, faces


def mesh_moments(path):
    vertices, faces = read_mesh(path)
    moments = [Q(0)] * 10
    edges = Counter()
    directed = Counter()
    for face in faces:
        assert len(set(face)) == 3 and min(face) >= 0 and max(face) < len(vertices)
        p = [vertices[i] for i in face]
        normal = cross(tuple(p[1][i]-p[0][i] for i in range(3)),
                       tuple(p[2][i]-p[0][i] for i in range(3)))
        assert any(normal)
        for a, b in zip(face, (face[1], face[2], face[0])):
            edges[tuple(sorted((a, b)))] += 1
            directed[(a, b)] += 1
        determinant = sum(p[0][i]*cross(p[1], p[2])[i] for i in range(3))
        volume = determinant / 6
        sums = [sum(q[i] for q in p) for i in range(3)]
        moments[0] += volume
        for axis in range(3):
            moments[1+axis] += volume * sums[axis] / 4
            moments[4+axis] += volume * (sums[axis]**2 + sum(q[axis]**2 for q in p)) / 20
        for index, (a, b) in enumerate(((0, 1), (1, 2), (0, 2)), 7):
            moments[index] += volume * (sums[a]*sums[b] + sum(q[a]*q[b] for q in p)) / 20
    closed = all(count == 2 for count in edges.values())
    oriented = all(directed[(a, b)] == directed[(b, a)] == 1 for a, b in edges)
    return moments, {"vertices": len(vertices), "faces": len(faces),
                     "undirected_edges": len(edges), "closed_edge_incidence_two": closed,
                     "opposite_directed_edge_incidence_one": oriented,
                     "all_triangle_areas_exactly_nonzero": True}


def box_moments(lo, hi):
    result = []
    for powers in EXPONENTS:
        value = Q(1)
        for power in powers:
            value *= Q(hi**(power+1)-lo**(power+1), power+1)
        result.append(value)
    return result


def dump_moments(values):
    return {name: str(value) for name, value in zip(MOMENT_NAMES, values)}


def main():
    a, b = WORK / "box_A_0_2.obj", WORK / "box_B_1_3.obj"
    write_cube(a, 0, 2)
    write_cube(b, 1, 3)
    am, bm, im = box_moments(0, 2), box_moments(1, 3), box_moments(1, 2)
    expected = {
        "union": [x+y-z for x, y, z in zip(am, bm, im)],
        "intersection": im,
        "subtraction": [x-z for x, z in zip(am, im)],
    }
    report = {
        "schema": "W4_P19_PINNED_NATIVE_ANALYTICAL_SMOKE_V1",
        "binary": str(BINARY), "binary_sha256": sha(BINARY),
        "inputs": [{"path": str(p), "sha256": sha(p)} for p in (a, b)],
        "analytical_case": "A=[0,2]^3; B=[1,3]^3; intersection=[1,2]^3",
        "moment_order": list(MOMENT_NAMES),
        "coordinate_semantics": "Exact Fraction.from_float of saved OBJ binary64 coordinates",
        "coordinate_tolerance": None,
        "mesh_repair_or_welding_performed": False,
        "checks": [],
        "scope": "Three original Cherchi operations on small analytical boxes only; no W0/W2 admission, Teapot certification, or implicit rational output certificate.",
    }
    for path, exact in ((a, am), (b, bm)):
        actual, topology = mesh_moments(path)
        assert actual == exact and topology["closed_edge_incidence_two"] and topology["opposite_directed_edge_incidence_one"]
    env = dict(os.environ, OMP_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1")
    for operation, exact in expected.items():
        output = WORK / f"{operation}.obj"
        command = [str(BINARY), operation, str(a), str(b), str(output)]
        start = time.monotonic()
        result = subprocess.run(command, capture_output=True, text=True, env=env, timeout=60)
        duration = time.monotonic()-start
        (WORK / f"{operation}.stdout.log").write_text(result.stdout)
        (WORK / f"{operation}.stderr.log").write_text(result.stderr)
        item = {"operation": operation, "command": command, "returncode": result.returncode,
                "elapsed_seconds": duration, "output_path": str(output)}
        if result.returncode == 0 and output.is_file():
            actual, topology = mesh_moments(output)
            item.update({"output_sha256": sha(output), "topology": topology,
                         "expected_exact_moments": dump_moments(exact),
                         "actual_saved_binary64_exact_moments": dump_moments(actual),
                         "residual_exact_moments": dump_moments([x-y for x, y in zip(actual, exact)]),
                         "all_ten_moments_exactly_equal": actual == exact,
                         "passed": actual == exact and topology["closed_edge_incidence_two"] and topology["opposite_directed_edge_incidence_one"]})
        else:
            item["passed"] = False
        report["checks"].append(item)
    report["native_operation_calls"] = len(report["checks"])
    report["passed"] = all(item["passed"] for item in report["checks"])
    output_report = WORK / "analytical-smoke-report.json"
    output_report.write_text(json.dumps(report, indent=2)+"\n")
    print(json.dumps(report, indent=2))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
