from fractions import Fraction as F
import subprocess, unittest
from pathlib import Path
BIN=Path(__file__).with_name('m28_boundary_face_classifier')
def tetra(offset=(0,0,0)):
    x,y,z=map(F,offset)
    v=[(x,y,z),(x+1,y,z),(x,y+1,z),(x,y,z+1)]
    f=[(0,2,1),(0,1,3),(0,3,2),(1,2,3)]
    return v,f
def stream(a,b):
    av,af=a;bv,bf=b
    out=[f'{len(av)} {len(af)} {len(bv)} {len(bf)}']
    for v in av:out.append(' '.join(f'{x.numerator}/{x.denominator}' for x in v))
    out += [' '.join(map(str,f)) for f in af]
    for v in bv:out.append(' '.join(f'{x.numerator}/{x.denominator}' for x in v))
    out += [' '.join(map(str,f)) for f in bf]
    return '\n'.join(out)+'\n'
def run(a,b):
    p=subprocess.run([str(BIN),'--max-seconds','10','--face-start','0','--face-end',str(len(a[1]))],input=stream(a,b),text=True,capture_output=True,timeout=15)
    rows=[x for x in p.stdout.splitlines() if x.startswith('face=')]
    summary={}
    for line in p.stdout.splitlines():
        if '=' in line and not line.startswith('face='):
            k,v=line.split('=',1);summary[k]=v
    return p,rows,summary
class TestFaceCutClassifier(unittest.TestCase):
    def test_separated_closed_shells_all_uncut(self):
        p,rows,s=run(tetra(),tetra((3,0,0)))
        self.assertEqual(p.returncode,0,p.stdout+p.stderr)
        self.assertEqual(len(rows),4)
        self.assertEqual(s['cut_faces'],'0')
        self.assertEqual(s['uncut_faces'],'4')
    def test_intersecting_shells_have_cut_faces(self):
        p,rows,s=run(tetra(),tetra((F(1,2),0,0)))
        self.assertEqual(p.returncode,0,p.stdout+p.stderr)
        self.assertGreater(int(s['cut_faces']),0)
    def test_face_range_is_respected(self):
        a,b=tetra(),tetra((3,0,0))
        p=subprocess.run([str(BIN),'--max-seconds','10','--face-start','1','--face-end','3'],input=stream(a,b),text=True,capture_output=True,timeout=15)
        self.assertEqual(p.returncode,0,p.stdout+p.stderr)
        self.assertIn('faces_processed=2',p.stdout)
    def test_invalid_range_fails_closed(self):
        a,b=tetra(),tetra((3,0,0))
        p=subprocess.run([str(BIN),'--max-seconds','10','--face-start','3','--face-end','2'],input=stream(a,b),text=True,capture_output=True,timeout=15)
        self.assertEqual(p.returncode,4)
        self.assertIn('INVALID_FACE_RANGE',p.stdout)
if __name__=='__main__':unittest.main()
