from fractions import Fraction as F
import tempfile, unittest
from pathlib import Path
import m28_3_face_coverage as m

class TestM28_3Coverage(unittest.TestCase):
    def test_design_intersection_keeps_inside(self):
        self.assertTrue(m.expected_retained("design","intersection","INSIDE"))
        self.assertFalse(m.expected_retained("design","intersection","OUTSIDE"))
    def test_design_difference_keeps_outside(self):
        self.assertTrue(m.expected_retained("design","difference","OUTSIDE"))
        self.assertFalse(m.expected_retained("design","difference","INSIDE"))
    def test_source_intersection_keeps_inside(self):
        self.assertTrue(m.expected_retained("source","intersection","INSIDE"))
        self.assertFalse(m.expected_retained("source","intersection","OUTSIDE"))
    def test_source_difference_keeps_inside(self):
        self.assertTrue(m.expected_retained("source","difference","INSIDE"))
        self.assertFalse(m.expected_retained("source","difference","OUTSIDE"))
    def test_uncut_retained_face_requires_exact_full_area(self):
        self.assertEqual(m.verify_uncut_area(F(12,7),F(12,7),True),F(12,7))
    def test_uncut_excluded_face_requires_zero_area(self):
        self.assertEqual(m.verify_uncut_area(F(12,7),F(0),False),F(0))
    def test_missing_area_is_rejected(self):
        with self.assertRaisesRegex(ValueError,"MISSING"):
            m.verify_uncut_area(F(1),F(1,2),True)
    def test_unexpected_area_is_rejected(self):
        with self.assertRaisesRegex(ValueError,"UNEXPECTED"):
            m.verify_uncut_area(F(1),F(1,2),False)
    def test_boundary_side_is_not_decisive(self):
        with self.assertRaisesRegex(ValueError,"NOT_DECISIVE"):
            m.expected_retained("design","intersection","ON_BOUNDARY")
    def test_unsupported_operation_fails_closed(self):
        with self.assertRaisesRegex(ValueError,"UNSUPPORTED"):
            m.expected_retained("design","union","INSIDE")
    def test_cut_classifier_parser_accepts_complete_rows(self):
        raw="""schema=x\nface=0;cut=1;candidates=2;exact=2;boundary_contacts=0\nface=1;cut=0;candidates=0;exact=0;boundary_contacts=0\nstatus=COMPLETE_INPUT_FACE_CUT_CLASSIFICATION\nface_start=0\nface_end=2\nfaces_processed=2\ncandidate_pairs=2\nexact_pairs_checked=2\ncut_faces=1\nuncut_faces=1\nboundary_contact_pairs=0\nelapsed_seconds=0.1\n"""
        rows,summary=m.parse_cut_scan(raw,2)
        self.assertEqual(rows[0]["cut"],1);self.assertEqual(rows[1]["cut"],0)
        self.assertEqual(summary["cut_faces"],1)
    def test_cut_classifier_parser_rejects_incomplete_rows(self):
        with self.assertRaisesRegex(ValueError,"INCOMPLETE"):
            m.parse_cut_scan("status=COMPLETE_INPUT_FACE_CUT_CLASSIFICATION\n",1)
    def test_checkpoint_append_round_trip(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/"checkpoint.jsonl"
            m.append_checkpoint(p,{"face":3,"status":"CUT_UNRESOLVED"})
            self.assertEqual(p.read_text().count("\n"),1)

if __name__=="__main__":unittest.main()
