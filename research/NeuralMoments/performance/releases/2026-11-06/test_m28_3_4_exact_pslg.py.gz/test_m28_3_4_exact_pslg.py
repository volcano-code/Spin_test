import unittest
from fractions import Fraction as Q
from m28_3_4_exact_pslg import (audit_parent, seg_intersections, _split_segments,
    project_coplanar_geometry, extract_cut_segments_3d, audit_parent_3d)
A=(0,0); B=(2,0); C=(0,2); M=(1,1); N=(1,0); D=(0,1)
P=(A,B,C)
class ExactPSLG(unittest.TestCase):
 def test_triangle_no_cuts_one_cell(self):
  r=audit_parent(P,[],[],lambda p:True)
  self.assertEqual((r["bounded_cells"],r["parent_area"],r["missing_area"]),(1,Q(2),Q(2)))
 def test_diagonal_cut_two_cells_and_coverage(self):
  r=audit_parent(P,[(A,M)],[(A,M,C)],lambda p:p[1]>p[0])
  self.assertTrue(r["passes"]);self.assertEqual(r["bounded_cells"],3)
 def test_crossing_segments_are_noded(self):
  edges=_split_segments([((0,0),(2,2)),((0,2),(2,0))])
  self.assertIn(tuple(sorted(((Q(0),Q(0)),(Q(1),Q(1))))),edges)
  self.assertIn(tuple(sorted(((Q(1),Q(1)),(Q(2),Q(2))))),edges)
  self.assertIn(tuple(sorted(((Q(0),Q(2)),(Q(1),Q(1))))),edges)
  self.assertIn(tuple(sorted(((Q(1),Q(1)),(Q(2),Q(0))))),edges)
 def test_collinear_overlap_is_split(self):
  self.assertEqual(seg_intersections(A,B,N,C),{N})
  edges=_split_segments([(A,B),(N,(Q(3,2),0))])
  self.assertEqual(len(edges),3)
 def test_vertical_cut(self):
  r=audit_parent(P,[(N,(1,1))],[],lambda p:p[0]<1)
  self.assertGreater(r["bounded_cells"],0)
 def test_duplicate_output_detected(self):
  r=audit_parent(P,[],[(A,B,M),(A,B,M)],lambda p:True)
  self.assertGreater(r["overlap_area"],0);self.assertFalse(r["passes"])
 def test_wrong_half_equal_area_detected(self):
  r=audit_parent(P,[(A,M)],[(A,B,M)],lambda p:p[1]>p[0])
  self.assertEqual(r["missing_area"],Q(1));self.assertEqual(r["extra_area"],Q(1))
 def test_sub_ulp_exact_sliver(self):
  h=Q(1,10**80)
  r=audit_parent(P,[((h,0),(0,h))],[],lambda p:p[0]+p[1]<h)
  self.assertGreater(r["missing_area"],0)
 def test_disconnected_closed_cut_loop_partitions_parent(self):
  square=((Q(1,2),Q(1,2)),(Q(1),Q(1,2)),(Q(1),Q(1)),(Q(1,2),Q(1)))
  cuts=list(zip(square,square[1:]+square[:1]))
  r=audit_parent(P,cuts,[(A,B,C)],lambda p:True)
  self.assertTrue(r["passes"])
  self.assertEqual(r["partition_area"],Q(2))
 def test_nested_cut_loop_missing_region_detected(self):
  square=((Q(1,2),Q(1,2)),(Q(1),Q(1,2)),(Q(1),Q(1)),(Q(1,2),Q(1)))
  cuts=list(zip(square,square[1:]+square[:1]))
  r=audit_parent(P,cuts,[],lambda p: Q(1,2)<p[0]<1 and Q(1,2)<p[1]<1)
  self.assertEqual(r["missing_area"],Q(1,4))
 def test_project_exact_3d_plane(self):
  parent=((0,0,0),(2,0,0),(0,2,0))
  p,c,o,axis=project_coplanar_geometry(parent,[],[parent])
  self.assertEqual(axis,2);self.assertEqual(p,((Q(0),Q(0)),(Q(2),Q(0)),(Q(0),Q(2))))
 def test_projection_rejects_non_coplanar_point(self):
  parent=((0,0,0),(2,0,0),(0,2,0))
  with self.assertRaisesRegex(ValueError,"NONCOPLANAR"):
   project_coplanar_geometry(parent,[((0,0,1),(1,0,0))],[])
 def test_extract_non_coplanar_3d_cut(self):
  parent=((0,0,0),(2,0,0),(0,2,0))
  verts=((1,-1,-1),(1,2,1),(1,2,-1))
  cuts=extract_cut_segments_3d(parent,verts,[(0,1,2)])
  self.assertEqual(len(cuts),1)
  self.assertEqual(set(cuts[0]),{(Q(1),Q(1,2),Q(0)),(Q(1),Q(1),Q(0))})
 def test_extract_coplanar_overlap_patch(self):
  parent=((0,0,0),(2,0,0),(0,2,0))
  other=((0,0,0),(1,0,0),(0,1,0))
  cuts=extract_cut_segments_3d(parent,other,[(0,1,2)])
  self.assertEqual(len(cuts),3)
  r=audit_parent_3d(parent,cuts,[other],lambda p:p[0]+p[1]<1)
  self.assertTrue(r["passes"])
 def test_reject_nonexact_and_outside(self):
  with self.assertRaises(ValueError): audit_parent(P,[],[[(0.,0),B,M]],lambda p:True)
  with self.assertRaises(ValueError): audit_parent(P,[],[(A,B,(3,0))],lambda p:True)

 def test_real_eval4_design_face_8698_cut_regression(self):
  parent=tuple(tuple(Q(int(a,0),int(b,0)) for a,b in (token.split("/") for token in row)) for row in (
   ("-1055236236963311/562949953421312","-7853151910625281/1125899906842624","171547037/4194304"),
   ("-661171309833711/562949953421312","-7853151910625281/1125899906842624","174483037/4194304"),
   ("-1055236236963311/562949953421312","-7853151910625281/1125899906842624","174483037/4194304")))
  other=tuple(tuple(Q(int(a,0),int(b,0)) for a,b in (token.split("/") for token in row)) for row in (
   ("2569669258531477/70368744177664","1890427407597711/70368744177664","753356365465037/17592186044416"),
   ("1159996687242757/1125899906842624","-3472790696192079/281474976710656","-2647143387784493/140737488355328"),
   ("-1789667932624359/549755813888","-3150253569384225/1099511627776","3449127242930733/8796093022208")))
  cuts=extract_cut_segments_3d(parent,other,[(0,1,2)])
  self.assertEqual(len(cuts),1)
  self.assertEqual(len(cuts[0]),2)

if __name__=="__main__":unittest.main()
