# W1 M28.3.4 — exact rational PSLG noding, cell coverage and first real cut-face replay

**Date:** 2026-11-06  
**Repository:** `volcano-code/Spin_test`  
**Branch:** `research/neuralmoments-w1-native-20261019`  
**Parent revision:** `d8d5d37d0e212844ac08d0cebbddc90ca8c64296`  
**Original evidence archive SHA-256:** `0c0962173694415b07578bae4375b9702251d0078b5c3a20935836e96d938976`

## Implementation

`m28_3_4_exact_pslg.py` implements:

- Exact Fraction segment intersection and noding, including proper crossings, endpoint contacts and collinear overlaps.
- Exact 3D-to-2D projection of parent/cut/output geometry; non-coplanar points fail closed.
- Exact coplanar triangle clipping to extract overlap-patch boundaries.
- Exact non-coplanar triangle/parent intersection segment extraction.
- Exact vertical-decomposition of the fully noded planar arrangement. The vertical sweep supports disconnected and nested cut loops; it avoids treating a disconnected PSLG as a single simple half-edge cycle.
- Exact rational cell area integration and exact missing/extra/multiply-covered output accounting.

A correctness defect found during real-data replay was fixed: the first cut-segment prototype had interchanged the two sets of signed distances (parent vertices to the opposite plane vs. opposite vertices to the parent plane). The corrected implementation now evaluates each point set against the plane it actually belongs to. A frozen real-data regression for evaluation 4, design face 8698, source face 279 prevents recurrence.

## Tests

- M28.3.4 kernel: **16/16 passed**.
- M28.3.3 extraction regression: **5/5 passed**.
- Combined: **21/21 passed**, no failures or skips.

Coverage includes collinear overlaps, proper crossings, vertical cuts, disconnected/nested loops, duplicate output coverage, equal-area wrong-side output, 10^-80 exact slivers, 3D coplanarity, coplanar overlap clipping, and the real cut-face regression.

## First real-data cut-parent-face audit

Using the original evidence archive with all 33 manifest entries rehashed successfully:

- Evaluation 4, Boolean `intersection`.
- Design parent triangle index **8698**.
- Opposite source mesh: all **568** faces scanned.
- Exactly one source face (index **279**) contributes one exact cut segment.
- Saved Boolean output face index **9273** maps uniquely to this parent.
- Exact planar arrangement has **4 cells**.
- The exact sum of cells classified inside the source equals the exact projected area of the saved output triangle.
- Missing, extra and overlap areas are all exactly **0**.

This is the first actual saved-material cut-parent-face coverage pass, not a synthetic fixture. It validates one parent face only; it does not yet validate the other 1,554 cut faces or global connectivity.

## Scientific limits

No new Cherchi Boolean or Newton call was made. The run uses the immutable saved Boolean packet, exact rational coordinates and the exact source solid membership classifier. The global Boolean boundary completeness flag remains false; production admission remains false; production-native ten-moment equality, 10×10 Jacobian, smooth-neighborhood certification, Newton convergence and full-solver speedup remain unverified (`full_solver_speedup=null`).

## Next M28.3.5

Scale the same exact procedure with restartable per-parent-face receipts: first batch the remaining cut faces of evaluation 4, then evaluations 116 and 117; aggregate exact missing/extra/overlap area and connected-component evidence. Unsupported degeneracies must fail closed. Only after all cut faces pass may global boundary completeness be considered.

## Cloud/local

Kernel development, 21 tests and the first real cut-face replay were completed in the cloud. No local action is needed for M28.3.5. Production Cherchi moments, native Jacobian, Newton convergence and final A/B/B/A still require the pinned native environment.
