# W1 M28.3.4 — exact rational noding and planar cell arrangement kernel

**Date:** 2026-11-06  
**Repository:** `volcano-code/Spin_test`  
**Branch:** `research/neuralmoments-w1-native-20261019`  
**Base revision:** `249db334303b31b8b8c2cfcb415b21a7cc2c9464`

## Delivered

A standalone exact-rational arrangement kernel was added. It builds on the M28.3.3 segment-extraction prototype and M28.3.2 cut-cell coverage prototype.

- Exact segment noding includes proper intersections, endpoint contacts and collinear overlap endpoints.
- A 3D parent triangle and all supplied cut/output geometry are projected into an exact rational 2D chart. Non-coplanar inputs are rejected.
- Coplanar opposite-operand triangles are clipped against the parent triangle with exact Sutherland–Hodgman clipping; the overlap polygon boundary becomes arrangement cuts.
- The arrangement is audited with exact vertical decomposition. Unlike a single-cycle half-edge face walk, this supports disconnected and nested closed cut loops without silently dropping holes.
- Each open slab has invariant segment order after exact x-event noding. The area between two affine segment boundaries is integrated exactly.
- Every cell is checked against caller-supplied exact membership and output-triangle coverage; missing, extra and multiply covered areas are accumulated as exact fractions.

## Tests actually run

- M28.3.4: **15/15** passing.
- M28.3.3 cut-extraction regression: **5/5** passing.
- Combined: **20/20**, no failures, no skips.

Cases include proper crossing, collinear overlap, vertical segments, closed disconnected loops, nested cut loops, same-area wrong-side output, duplicate coverage, 10^-80 sliver, 3D exact plane projection, non-coplanarity rejection, non-coplanar cut extraction and coplanar overlap clipping.

## Important limitations

This is a tested geometry kernel, **not yet the global real-data M28.3 audit**. It has not processed the 1,555 real cut parent faces. The real cut-segment set still must be extracted from all opposite operand faces, including robust coplanar patch handling and complete intersection-curve noding. Membership callbacks must be supplied from the authenticated exact solid classifier, not sampled or inferred from output labels.

No new Cherchi Boolean or Newton was run. `real_global_boolean_completeness_certified=false`, `production_admitted=false`, `full_solver_speedup=null`.

## Next M28.3.5

Build a bounded, restartable real-data driver: start with a small frozen batch of cut parent faces for evaluation 4, derive all exact non-coplanar/coplanar cuts from the opposite operand, run this arrangement kernel, cross-check area against the saved output packet, persist per-parent-face receipts, then scale to all 1,555 cut faces and the remaining evaluations. Any unsupported degeneracy must fail closed.

## Cloud/local

M28.3.4 implementation and synthetic tests ran in the cloud; no local operation was required. Real native Cherchi ten moments, full Jacobian, Newton convergence and final A/B/B/A still require the pinned native environment.
