"""Exact rational PSLG noding and bounded-cell enumeration in a parent triangle.

All input coordinates must be int/Fraction. Segment intersections, collinear
overlap splitting, graph embedding, face enumeration and cell areas are exact.
This module is a geometry kernel; membership predicates are supplied by caller.
"""
from fractions import Fraction as Q
from functools import cmp_to_key

def P(p):
    if len(p)!=2 or any(type(x) not in (int,Q) for x in p):
        raise ValueError("NONEXACT_2D_POINT")
    return tuple(map(Q,p))
def sub(a,b): return (a[0]-b[0],a[1]-b[1])
def add(a,b): return (a[0]+b[0],a[1]+b[1])
def mul(a,t): return (a[0]*t,a[1]*t)
def cross(a,b): return a[0]*b[1]-a[1]*b[0]
def area2(poly): return sum(cross(poly[i],poly[(i+1)%len(poly)]) for i in range(len(poly)))
def on_segment(p,a,b):
    d=sub(b,a); w=sub(p,a)
    return cross(d,w)==0 and min(a[0],b[0])<=p[0]<=max(a[0],b[0]) and min(a[1],b[1])<=p[1]<=max(a[1],b[1])
def param(p,a,b):
    d=sub(b,a)
    if abs(d[0])>=abs(d[1]):
        if d[0]==0: return Q(0)
        return (p[0]-a[0])/d[0]
    return (p[1]-a[1])/d[1]
def seg_intersections(a,b,c,d):
    """Return exact points common to two closed segments, including overlap endpoints."""
    r=sub(b,a); s=sub(d,c); q=sub(c,a); den=cross(r,s)
    if den:
        t=cross(q,s)/den; u=cross(q,r)/den
        if 0<=t<=1 and 0<=u<=1: return {add(a,mul(r,t))}
        return set()
    if cross(q,r): return set()
    return {p for p in (a,b,c,d) if on_segment(p,a,b) and on_segment(p,c,d)}
def _angle_cmp(origin,a,b):
    va=sub(a,origin); vb=sub(b,origin)
    ha=0 if (va[1]>0 or (va[1]==0 and va[0]>=0)) else 1
    hb=0 if (vb[1]>0 or (vb[1]==0 and vb[0]>=0)) else 1
    if ha!=hb: return -1 if ha<hb else 1
    z=cross(va,vb)
    if z: return -1 if z>0 else 1
    da=va[0]*va[0]+va[1]*va[1]; db=vb[0]*vb[0]+vb[1]*vb[1]
    return (da>db)-(da<db)
def _split_segments(segments):
    clean=[]
    for a,b in segments:
        a=P(a); b=P(b)
        if a==b: continue
        clean.append((a,b))
    cuts=[{a,b} for a,b in clean]
    for i,(a,b) in enumerate(clean):
        for j in range(i+1,len(clean)):
            c,d=clean[j]
            common=seg_intersections(a,b,c,d)
            if common:
                cuts[i].update(common); cuts[j].update(common)
    edges=set()
    for (a,b),points in zip(clean,cuts):
        ordered=sorted(points,key=lambda p:param(p,a,b))
        for x,y in zip(ordered,ordered[1:]):
            if x!=y: edges.add(tuple(sorted((x,y))))
    return sorted(edges)
def _faces_from_edges(edges):
    adj={}
    for a,b in edges:
        adj.setdefault(a,set()).add(b); adj.setdefault(b,set()).add(a)
    ordered={v:sorted(ns,key=cmp_to_key(lambda a,b:_angle_cmp(v,a,b))) for v,ns in adj.items()}
    pos={v:{n:i for i,n in enumerate(ns)} for v,ns in ordered.items()}
    visited=set(); faces=[]
    for a,b in edges:
        for start in ((a,b),(b,a)):
            if start in visited: continue
            cycle=[]; u,v=start
            for _ in range(4*len(edges)+8):
                if (u,v) in visited:
                    if (u,v)!=start: raise ValueError("PSLG_HALFEDGE_REVISIT")
                    break
                visited.add((u,v)); cycle.append(u)
                ns=ordered[v]; idx=pos[v][u]
                w=ns[(idx-1)%len(ns)] # keep the face on the left
                u,v=v,w
                if (u,v)==start: break
            else: raise ValueError("PSLG_FACE_WALK_LIMIT")
            if len(cycle)>=3:
                # Remove collinear intermediate vertices.
                compact=[]
                for p in cycle:
                    while len(compact)>=2 and cross(sub(compact[-1],compact[-2]),sub(p,compact[-1]))==0:
                        compact.pop()
                    compact.append(p)
                changed=True
                while changed and len(compact)>=3:
                    changed=False
                    for k in range(len(compact)):
                        x=compact[k-1]; y=compact[k]; z=compact[(k+1)%len(compact)]
                        if cross(sub(y,x),sub(z,y))==0:
                            compact.pop(k); changed=True; break
                if len(compact)>=3 and area2(compact)>0:
                    faces.append(tuple(compact))
    # Unique cycles by canonical rotation.
    unique={}
    for f in faces:
        k=min(tuple(f[i:]+f[:i]) for i in range(len(f)))
        unique[k]=f
    return list(unique.values())
def _point_in_tri(p,t):
    signs=[cross(sub(t[(i+1)%3],t[i]),sub(p,t[i])) for i in range(3)]
    return min(signs)>=0 or max(signs)<=0
def _ear_sample(poly):
    v=list(poly)
    if area2(v)<0: v.reverse()
    # Ear clipping; exact convexity and exact point containment.
    while len(v)>3:
        found=False
        for i in range(len(v)):
            a,b,c=v[i-1],v[i],v[(i+1)%len(v)]
            if cross(sub(b,a),sub(c,b))<=0: continue
            tri=(a,b,c)
            if any(_point_in_tri(p,tri) for j,p in enumerate(v) if j not in (i-1,i,(i+1)%len(v))):
                continue
            return tuple((a[k]+b[k]+c[k])/3 for k in range(2))
        if not found: break
    if len(v)>=3:
        return tuple(sum(p[k] for p in v)/len(v) for k in range(2))
    raise ValueError("PSLG_CELL_SAMPLE_FAILED")
def point_in_polygon(p,poly):
    # exact ray parity, boundary counts as inside
    inside=False
    for a,b in zip(poly,poly[1:]+poly[:1]):
        if on_segment(p,a,b): return True
        if (a[1]>p[1]) != (b[1]>p[1]):
            x=a[0]+(p[1]-a[1])*(b[0]-a[0])/(b[1]-a[1])
            if x>p[0]: inside=not inside
    return inside
def _y_at(segment,x):
    a,b=segment
    if a[0]==b[0]: return None
    return a[1]+(x-a[0])*(b[1]-a[1])/(b[0]-a[0])

def _inside_triangle(p,t):
    signs=[cross(sub(t[(i+1)%3],t[i]),sub(p,t[i])) for i in range(3)]
    return min(signs)>=0 or max(signs)<=0

def audit_parent(parent,cuts,output_triangles,keep):
    """Exact vertical decomposition; handles disconnected/nested PSLG components.

    The parent boundary, every cut and every output edge enter one exact
    arrangement. All pairwise segment intersections are noded first. Between
    consecutive x-events, segment order is invariant; each adjacent y-band is
    one arrangement cell. Its area is the exact integral of two affine edges.
    """
    parent=tuple(P(p) for p in parent)
    if len(parent)!=3 or area2(parent)==0: raise ValueError("INVALID_PARENT_TRIANGLE")
    if area2(parent)<0: parent=(parent[0],parent[2],parent[1])
    boundary=list(zip(parent,parent[1:]+parent[:1]))
    segments=boundary+[tuple(map(P,s)) for s in cuts]
    outputs=[]
    for tri in output_triangles:
        tri=tuple(P(p) for p in tri)
        if len(tri)!=3 or area2(tri)==0: raise ValueError("INVALID_OUTPUT_TRIANGLE")
        if not all(point_in_polygon(p,parent) for p in tri): raise ValueError("OUTPUT_OUTSIDE_PARENT")
        outputs.append(tri)
        segments.extend(zip(tri,tri[1:]+tri[:1]))
    edges=_split_segments(segments)
    events=sorted({p[0] for edge in edges for p in edge})
    observed=missing=extra=overlap=Q(0)
    cells=0
    for xl,xr in zip(events,events[1:]):
        if xl==xr: continue
        xm=(xl+xr)/2
        active=[]
        for edge in edges:
            a,b=edge
            if a[0]==b[0] or not (a[0]<xm<b[0]): continue
            y=_y_at(edge,xm)
            if y is not None: active.append((y,edge))
        active.sort(key=lambda item:(item[0],item[1]))
        # Duplicate coincident segments have already been noded/deduplicated.
        unique=[]
        for item in active:
            if unique and item[0]==unique[-1][0]:
                # Different segments can meet only at an x-event, not inside this slab.
                raise ValueError("UNNODED_COINCIDENT_INTERIOR_SEGMENTS")
            unique.append(item)
        for (yl,lower),(yu,upper) in zip(unique,unique[1:]):
            if yl==yu: continue
            sample=(xm,(yl+yu)/2)
            if not point_in_polygon(sample,parent): continue
            want=keep(sample)
            if type(want) is not bool: raise ValueError("AMBIGUOUS_CELL_MEMBERSHIP")
            count=sum(_inside_triangle(sample,t) for t in outputs)
            ll=_y_at(lower,xl); lr=_y_at(lower,xr)
            ul=_y_at(upper,xl); ur=_y_at(upper,xr)
            if None in (ll,lr,ul,ur): raise ValueError("VERTICAL_CELL_BOUNDARY")
            area=(xr-xl)*((ul-ll)+(ur-lr))/2
            if area<=0: raise ValueError("NONPOSITIVE_CELL_AREA")
            observed+=area; cells+=1
            if want and count==0: missing+=area
            if not want and count>0: extra+=area
            if count>1: overlap+=area
    expected_area=abs(area2(parent))/2
    if observed!=expected_area:
        raise ValueError(f"PSLG_AREA_PARTITION_MISMATCH:{observed}!={expected_area}")
    return dict(vertices=len({p for e in edges for p in e}),split_edges=len(edges),
                bounded_cells=cells,parent_area=expected_area,partition_area=observed,
                missing_area=missing,extra_area=extra,overlap_area=overlap,
                passes=not(missing or extra or overlap))


def project_coplanar_geometry(parent3d,cuts3d,output3d):
    """Project exact 3D coplanar data to a stable 2D coordinate chart.

    Returns (parent2d, cuts2d, output2d, dropped_axis). Every supplied point
    must lie exactly on the parent plane; no floating tolerance is used.
    """
    parent3d=tuple(tuple(map(Q,p)) for p in parent3d)
    if len(parent3d)!=3 or any(len(p)!=3 for p in parent3d):
        raise ValueError("INVALID_3D_PARENT")
    n=cross3(sub3(parent3d[1],parent3d[0]),sub3(parent3d[2],parent3d[0]))
    if n==(0,0,0): raise ValueError("DEGENERATE_3D_PARENT")
    axis=max(range(3),key=lambda k:abs(n[k]))
    def project(p):
        p=tuple(map(Q,p))
        if len(p)!=3 or dot3(n,sub3(p,parent3d[0]))!=0:
            raise ValueError("NONCOPLANAR_3D_INPUT")
        return (p[1],p[2]) if axis==0 else ((p[0],p[2]) if axis==1 else (p[0],p[1]))
    parent2=tuple(project(p) for p in parent3d)
    cuts2=[(project(a),project(b)) for a,b in cuts3d]
    output2=[tuple(project(p) for p in tri) for tri in output3d]
    return parent2,cuts2,output2,axis

def sub3(a,b): return tuple(x-y for x,y in zip(a,b))
def dot3(a,b): return sum(x*y for x,y in zip(a,b))
def cross3(a,b): return (a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])


def _clip_convex(subject,clip):
    """Exact Sutherland-Hodgman intersection of two convex 2D polygons."""
    subject=list(subject); clip=tuple(clip)
    sign=1 if area2(clip)>0 else -1
    for a,b in zip(clip,clip[1:]+clip[:1]):
        if not subject: break
        old=subject; subject=[]
        for x,y in zip(old,old[1:]+old[:1]):
            sx=cross(sub(b,a),sub(x,a))*sign
            sy=cross(sub(b,a),sub(y,a))*sign
            xin=sx>=0; yin=sy>=0
            if xin and yin: subject.append(y)
            elif xin and not yin:
                t=sx/(sx-sy); subject.append(add(x,mul(sub(y,x),t)))
            elif not xin and yin:
                t=sx/(sx-sy); subject.extend((add(x,mul(sub(y,x),t)),y))
        # Remove consecutive duplicates.
        compact=[]
        for q in subject:
            if not compact or q!=compact[-1]: compact.append(q)
        if len(compact)>1 and compact[0]==compact[-1]: compact.pop()
        subject=compact
    return subject

def _restore_3d(p2,parent3d,axis):
    n=cross3(sub3(parent3d[1],parent3d[0]),sub3(parent3d[2],parent3d[0]))
    if axis==0:
        y,z=p2; x=parent3d[0][0]-(n[1]*(y-parent3d[0][1])+n[2]*(z-parent3d[0][2]))/n[0]
        return (x,y,z)
    if axis==1:
        x,z=p2; y=parent3d[0][1]-(n[0]*(x-parent3d[0][0])+n[2]*(z-parent3d[0][2]))/n[1]
        return (x,y,z)
    x,y=p2; z=parent3d[0][2]-(n[0]*(x-parent3d[0][0])+n[1]*(y-parent3d[0][1]))/n[2]
    return (x,y,z)

def _triangle_plane_segment(parent,other):
    a,b,c=parent; u,v,w=other
    np_=cross3(sub3(b,a),sub3(c,a)); no=cross3(sub3(v,u),sub3(w,u))
    if np_==(0,0,0) or no==(0,0,0): raise ValueError("DEGENERATE_TRIANGLE")
    sp=[dot3(no,sub3(x,u)) for x in parent]
    so=[dot3(np_,sub3(x,a)) for x in other]
    if all(x==0 for x in sp) and all(x==0 for x in so): return None
    if all(x>0 for x in sp) or all(x<0 for x in sp) or all(x>0 for x in so) or all(x<0 for x in so): return ()
    def hits(tri,vals,test,norm):
        result=[]
        for i in range(3):
            j=(i+1)%3
            if vals[i]==0:
                point=tri[i]
                if all(dot3(cross3(sub3(test[(k+1)%3],test[k]),sub3(point,test[k])),norm)>=0 for k in range(3)):
                    result.append(point)
            if vals[i]*vals[j]<0:
                t=vals[i]/(vals[i]-vals[j])
                point=tuple(tri[i][k]+t*(tri[j][k]-tri[i][k]) for k in range(3))
                if all(dot3(cross3(sub3(test[(k+1)%3],test[k]),sub3(point,test[k])),norm)>=0 for k in range(3)):
                    result.append(point)
        return result
    points=set(hits(other,sp,parent,np_)+hits(parent,so,other,no))
    if len(points)<2:return ()
    pair=max(((dot3(sub3(x,y),sub3(x,y)),x,y) for x in points for y in points if x<y),key=lambda z:z[0])
    return (pair[1],pair[2]) if pair[0] else ()

def extract_cut_segments_3d(parent3d,opposite_vertices,opposite_faces):
    """Extract noncoplanar intersection segments and coplanar overlap boundaries."""
    parent3d=tuple(tuple(map(Q,p)) for p in parent3d)
    all_segments=set()
    for face in opposite_faces:
        other=tuple(tuple(map(Q,opposite_vertices[i])) for i in face)
        if len(other)!=3: raise ValueError("INVALID_OPPOSITE_FACE")
        no=cross3(sub3(other[1],other[0]),sub3(other[2],other[0]))
        np_=cross3(sub3(parent3d[1],parent3d[0]),sub3(parent3d[2],parent3d[0]))
        if no==(0,0,0): raise ValueError("DEGENERATE_OPPOSITE_FACE")
        coplanar=(all(dot3(no,sub3(p,other[0]))==0 for p in parent3d) and
                  all(dot3(np_,sub3(p,parent3d[0]))==0 for p in other))
        if coplanar:
            parent2,_,other2,axis=project_coplanar_geometry(parent3d,[],[other])
            poly=_clip_convex(list(other2[0]),list(parent2))
            if len(poly)>=2:
                restored=[_restore_3d(p,parent3d,axis) for p in poly]
                for a,b in zip(restored,restored[1:]+restored[:1]):
                    if a!=b: all_segments.add(tuple(sorted((a,b))))
        else:
            segment=_triangle_plane_segment(parent3d,other)
            if segment:
                all_segments.add(tuple(sorted(segment)))
    return sorted(all_segments)

def audit_parent_3d(parent3d,cuts3d,output3d,keep3d):
    parent2,cuts2,output2,axis=project_coplanar_geometry(parent3d,cuts3d,output3d)
    def keep2(p):
        return keep3d(_restore_3d(p,tuple(tuple(map(Q,x)) for x in parent3d),axis))
    result=audit_parent(parent2,cuts2,output2,keep2)
    result["projection_axis_dropped"]=axis
    result["exact_3d_coplanarity_checked"]=True
    return result
